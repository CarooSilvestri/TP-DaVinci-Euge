<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/bootstrap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-3">
        <p>Lorem, ipsum</p>   
            </div>

    
        <img src="" alt="">
    </div>

    <div>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Labore molestiae saepe iste sit asperiores esse dolorum. Ducimus, ad sequi dolores quam perspiciatis ab cum veritatis amet blanditiis unde maiores accusantium?</p>
    </div>
        </div>


<div class="container">
    <div class="row">
        <div class="col">
            <p>Lorem, ipsum.</p>
        </div>
        <div class="col"><img src="img/bastardo.jpg" alt=""></div>
        <div class="col"><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio iure ab dicta quas nostrum, dolorum voluptate qui quidem veritatis enim sint odio at vero harum, rem perspiciatis? Voluptatem, accusantium nobis.</p></div>
    </div>
</div>







</body>
</html>