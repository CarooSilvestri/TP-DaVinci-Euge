<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/bootsrap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>


<div class="box">
    <img src="" alt="" class="rounded-circle">
    <h3 class="name">Lorem, ipsum.</h3>
    <p class="title">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam doloribus voluptates corrupti iure, repellendus non recusandae nobis architecto quis! Esse odit corrupti cupiditate? Cupiditate adipisci quas ex illum omnis corporis.</p>
</div>





</body>
</html>