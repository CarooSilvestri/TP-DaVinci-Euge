<?php
session_start(); 
//traigo el header
require 'parciales/header.php';
?>
<h2>Todo sobre tragobar</h2>
<p>Un grupo de bartenders que saben sobre programación te hacen conocer mas sobre los tragos su mundo</p>
<p>Tragobar está pensado en 3 ideas:</p>
<ol>
    <li>Primero es aprender más sobre la cultura de los cocteles, su sabor, aroma, textura y más.</li>
    <li>La segunda es aprender más sobre quienes los hacen, conocidos como bartenders son aquellas personas encargadas de elaborar estos tragos </li>
    <li>Por tercero tenemos los bares, cada uno de ellos único y distinto con sus temáticas, estilo, precio y hasta cómo encontrarlo. 
</li>
</ol>
<?php
//traigo el footer
require 'parciales/footer.php';
?>