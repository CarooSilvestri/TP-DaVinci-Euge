<?php
require 'parciales/header.php';
?>


<div class="container ">
    <div class="row">
        <div class="col sup center-block tarco">
        <div class="card tarjeta-color tar">
        <img class="card-img-top rounded-circle fototar img-fluid" src="img/yo.png" alt="Foto de mariano">
        <div class="card-body">
        <h4 class="card-title tarcol h3">Mariano Joaquin    Schicht</h4>
        <p>Carrera: Diseño multimedial</p>
        <p>Materia: Programación Visual III</p>
        <p>Comisión: DMM4A</p>
        <p>Profesor: Santiago Gallino</p>
        
    </div>
</div>

<?php
require 'parciales/footer.php';
